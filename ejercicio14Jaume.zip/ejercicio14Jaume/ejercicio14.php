<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<link href="indexstyle.css" rel="stylesheet" type="text/css">

<head>

</head>

<body>

<form method="get" action="Pagina2.php">

<label for="numbers">Entra el total de numeros que vulguis:</label>
<input type="number" name="numbers" step="1" max="20" min="1"/>
</br>
<input type="submit" name="enter" value="Enter"/>
</form>

  <?php


	?>
